# Velocity AI Systems Working Demo

Open `index.html` first.

Then click `View Live Demo`.

If the link ever fails, open `demo.html` directly. Both files must stay in the same folder.
